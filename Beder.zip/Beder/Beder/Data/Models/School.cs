﻿using System;
using Beder.Data;

namespace Beder.Controllers;

public class School : BaseClass
{
    public string Name { get; set; }
    public string Address { get; set; }
    public int YearEstablished { get; set; }
}