﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Beder.Data.VM;
using Microsoft.AspNetCore.Mvc;

namespace Beder.Controllers;

[Route("api/[controller]")]
[ApiController]
public class StudentController : ControllerBase
{
    [HttpPost]
    public IActionResult AddSchool([FromBody] StudentVM studentVM)
    {
        //Krijohet objekti shkolle
        var school = new Student()
        {
            //Id = Gjenerohet nga database
            FirstName = studentVM.FirstName,
            LastName = studentVM.LastName,
            DateOfBirth = studentVM.DateOfBirth,
            GraduationYear = studentVM.GraduationYear,

            //Mund te jene edhe ne nivel database
            DateCreated = DateTime.UtcNow,
            DateUpdated = null
        };

        //Objekti i krijuar shtohet ne databaze me Entity Framework
        return Created("", school);
    }

    [HttpPut("{id}")]
    public IActionResult UpdateStudent([FromBody] StudentVM studentVM, int id)
    {
        //Merret objekti Student nga database duket perdorur Id si parameter
        var student = new Student()
        {
            Id = id,
            FirstName = studentVM.FirstName,
            LastName = studentVM.LastName,
            DateOfBirth = studentVM.DateOfBirth,
            GraduationYear = studentVM.GraduationYear,
            DateUpdated = DateTime.UtcNow
        };


        return Ok($"Student with id = {id} was updated");
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteById(int id)
    {
        //NOTE: Kalohet Id si parameter dhe fshihet Studenti nga databaza

        return Ok($"Student with id {id} deleted");
    }
}